$(document).ready(function(){
	$(".myclick").click(function(){
		// $(".myfrm").css("display","block");
		$(".myfrm").toggle(200);
	});
});