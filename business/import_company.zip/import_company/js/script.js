/*script smooth scroll*/
	//script smooth*/
	jQuery(document).ready(function() {
	jQuery('.no').addClass("hidden").viewportChecker({
	    classToAdd: 'visible animated fadeInDown', // Class to add to the elements when they are visible
	    offset: 100    
	   });   
	}); 