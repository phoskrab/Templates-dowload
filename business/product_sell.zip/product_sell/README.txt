﻿===========================
INTRO
===========================
Amoogli provides free template for everyone who want to customize and it's for free.

===========================

===========================
We us bootstrap and plugin also.

===========================
Developed
===========================
Author : amoogli.com
Version : v.1.0
Created : 01 sep  2016
Email :Amooglikh@gmail.com


===========================
Credit
===========================
Framework Based
- Bootstrap V.3 - http://getbootstrap.com/

Font
- Open Sans - https://www.google.com/fonts#UsePlace:use/Collection:Open+Sans

Icons
- Font Awesome - https://fortawesome.github.io/Font-Awesome/

Javascript
- jQuery  - https://code.jquery.com/jquery/
- Bootstrap  - http://getbootstrap.com/
- IE  - https://github.com/twbs/bootstrap/tree/master/docs/assets/js

CSS
-  Animate - https://daneden.github.io/animate.css/
